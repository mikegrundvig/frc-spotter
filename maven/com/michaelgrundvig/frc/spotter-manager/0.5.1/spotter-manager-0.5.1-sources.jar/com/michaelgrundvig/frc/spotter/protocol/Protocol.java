package com.michaelgrundvig.frc.spotter.protocol;

/**
 * Spotter's protocol, version 2.0: HTTP on {@link #PORT}, its messages {@code spotter.proto}'s
 * ({@link Spotter}), in protobuf unless JSON is asked for. The version is in HTTP, never in a
 * message: the major version in the path ({@code /v2/}), and {@code major.minor} in the {@link
 * #HEADER} of every response, which a reader checks before it reads a byte of the body.
 */
public final class Protocol {
  /** The protocol's version, in {@link #HEADER} on every response. */
  public static final String VERSION = "2.0";

  /** The header every response carries the protocol's version in. */
  public static final String HEADER = "Spotter-Protocol";

  /** The agent's port unless its {@code agent.json} says otherwise: in FRC's team range. */
  public static final int PORT = 5808;

  /** Protobuf's media type: what every endpoint answers in unless JSON is asked for. */
  public static final String PROTOBUF = "application/x-protobuf";

  /** JSON's media type: asked for with {@code Accept}, it answers in QuickBuffers' JSON form. */
  public static final String JSON = "application/json";

  /** {@code GET}: the agent's {@code Description}. */
  public static final String DESCRIBE = "/v2/describe";

  /** {@code GET}: every value, as a complete {@code Values}. */
  public static final String VALUES = "/v2/values";

  /**
   * {@code GET ?heartbeat=250ms}: the stream, each {@code Event} preceded by its length as a
   * varint.
   */
  public static final String STREAM = "/v2/stream";

  /** {@code POST}: a bundle of pack folders ({@code PackBundle}), for a board that takes pushes. */
  public static final String PACKS = "/v2/packs";

  /** {@code GET /v2/logs/<id>?from=&cursor=&limit=&level=}: a {@code LogPage}. */
  public static final String LOGS = "/v2/logs/";

  /** {@code POST /v2/actions/<id>}: starts an action, its input the body. */
  public static final String ACTIONS = "/v2/actions/";

  /**
   * {@code GET /v2/runs/<run>}, {@code .../files/<field>}, {@code .../log}; {@code DELETE} cancels
   * it.
   */
  public static final String RUNS = "/v2/runs/";

  /** The header a stream's response carries its connection's challenge in. */
  public static final String CHALLENGE = "Spotter-Challenge";

  /** The header a signed write carries: {@code <key id> <counter> <signature>}. */
  public static final String SIGNATURE = "Spotter-Signature";

  /** The last number of the robot controller's address, 10.TE.AM.2: who may change a board. */
  public static final int CONTROLLER = 2;

  /**
   * The most one of a stream's events may be, in bytes. The manager refuses a longer one; the agent
   * sends none: it describes no more than fits, splits a board's values across events, and keeps a
   * run's response within {@link #MAX_RESPONSE}.
   */
  public static final int MAX_EVENT = 1 << 20;

  /**
   * The most a run's response may be, in bytes, as its events and its state carry it: a field of it
   * past that is unavailable, saying so. A {@code file} field is a URL, and downloads whole.
   */
  public static final int MAX_RESPONSE = 256 << 10;

  /** The most values a board may describe: the agent loads no more, the manager takes no more. */
  public static final int MAX_VALUES = 2048;

  /** The most actions a board may describe, its two built-in ones included. */
  public static final int MAX_ACTIONS = 128;

  /** The most problems a board may list: past them, the last says how many more there were. */
  public static final int MAX_PROBLEMS = 128;

  /**
   * The most a pushed bundle's files may hold, in bytes: packs are scripts and settings, and a
   * bundle is read whole into the agent's 64 MiB heap.
   */
  public static final long MAX_BUNDLE = 16L * 1024 * 1024;

  /** The most files a pushed bundle may hold. */
  public static final int MAX_FILES = 4096;

  /**
   * The longest one request may take, from connecting to the end of its answer, in seconds: a push
   * or an action's input sends at most 64 MiB, a few seconds on the robot's wired network and more
   * over its radio. The agent cuts off a request it hasn't wholly read by then, and the manager
   * drops one it hasn't had its answer to.
   */
  public static final int REQUEST_SECONDS = 30;

  private Protocol() {}
}
